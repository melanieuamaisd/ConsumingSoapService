-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2020 at 05:21 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employees`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `deptno` int(11) NOT NULL,
  `deptname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`deptno`, `deptname`) VALUES
(1004, 'Finance Department'),
(1001, 'General Management'),
(1010, 'Health Department'),
(1006, 'Human Resources Department'),
(1002, 'Marketing Management'),
(1003, 'Operations Department'),
(1007, 'Purchase Department'),
(1005, 'Sales Department'),
(1008, 'Technology Department'),
(1009, 'Tourism Department');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `empId` int(11) NOT NULL,
  `birthdate` date NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `hire_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`empId`, `birthdate`, `firstname`, `lastname`, `hire_date`) VALUES
(1, '1980-08-09', 'James', 'Johnson', '2000-10-17'),
(2, '1994-01-01', 'Justin', 'Anthony', '2012-04-04'),
(3, '2000-10-12', 'Florence', 'Richards', '2020-06-09'),
(4, '1999-08-24', 'Jennifer', 'DaBlock', '2012-04-04'),
(5, '1989-12-12', 'Linda', 'Williams', '2011-11-02'),
(6, '1990-07-26', 'Niklaus', 'Mikaelson', '2010-05-25'),
(7, '1991-12-31', 'Elena', 'Gille', '2020-06-09'),
(8, '1987-03-12', 'Charles', 'Charleston', '2012-04-04'),
(9, '1979-02-17', 'Peter', 'Hayes', '2000-10-17'),
(10, '1991-11-12', 'Andrew', 'Willis', '2012-04-04');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `empId` int(11) NOT NULL,
  `salary` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salaries`
--

INSERT INTO `salaries` (`empId`, `salary`, `from_date`, `to_date`) VALUES
(1, 50000, '2005-07-23', '2017-11-12'),
(2, 30000, '2012-04-04', '2020-10-12'),
(3, 30000, '2020-06-09', '2020-07-09'),
(4, 50500, '2012-04-04', '2020-10-12'),
(5, 37000, '2011-05-25', '2017-11-12'),
(6, 55000, '2010-05-25', '2017-10-12'),
(7, 40000, '2020-06-09', '2020-12-31'),
(8, 50000, '2015-02-17', '2020-10-12'),
(9, 57000, '2001-09-15', '2017-11-12'),
(10, 40000, '2012-04-04', '2020-10-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`deptname`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`empId`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`empId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
