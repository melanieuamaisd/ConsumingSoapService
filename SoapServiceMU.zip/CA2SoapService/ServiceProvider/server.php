<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//no parameters
function getEmployeeDetails(){
 $dsn = "mysql:host=localhost;dbname=employees";
 $username = "root";
 $password = "";
 try{

     $db = new PDO($dsn, $username, $password);

     $db->setAttribute(PDO::ATTR_EMULATE_PREPARES,FALSE);
     $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     error_reporting(E_ALL);
 } catch(PDOException $ex){
     header("Location:error.php?msg=" , $ex->getMessage());
 }

 $query = "SELECT * FROM employee";
 $statement = $db->prepare($query);
 $statement->execute();
 $results = $statement->fetchAll();
 $statement->closeCursor();
         
       $response = "<HTML>
    <HEAD>
        <TITLE>Employee Information table</TITLE>
    </HEAD>
    <BODY>
    <br>
    <table border>
    <tr>
    <th>Employee Id:</th>
    <th>Birthdate</th> 
    <th>Firstname</th>
    <th>Lastname</th>
    <th>Hire-date</th>
    </tr>";
    foreach($results as $rs){
        $response = $response .
        "<tr>
        <td>" .$rs['empId']."</td>
        <td>".$rs['birthdate']. "</td>
        <td>".$rs['firstname']. "</td>
        <td>".$rs['lastname']. "</td>
        <td>".$rs['hire_date']. "</td>
        </tr>";
    }
    $response = $response .
            "</table>
             </body>
             </html>";
    return $response;
 
  return json_encode($results);

 }

 //operation 1 parameters
 function getEmployeeNo($empId){
     $dsn = "mysql:host=localhost;dbname=employees";
     $username = "root";
     $password = "";

     try {
        $db = new PDO($dsn, $username,$password);
    
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES,FALSE);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        error_reporting(E_ALL);
    
      } catch(PDOException $ex){
    
        header("Location:error.php?msg="  . $ex->getMessage());
      }

      $query = "SELECT * from employee WHERE empId = :empId";
      $statement = $db->prepare($query);
      $statement->bindValue(":empId", $empId);
      $statement->execute();
      $results = $statement->fetchAll();
      $statement->closeCursor();
       $response = "<HTML>
    <HEAD>
        <TITLE>Employee Information table</TITLE>
    </HEAD>
    <BODY>
    <br>
    <table border>
    <tr>
    <th>Employee Id:</th>
    <th>Birthdate</th> 
    <th>Firstname</th>
    <th>Lastname</th>
    <th>Hire-date</th>
    </tr>";
    foreach($results as $rs){
        $response = $response .
        "<tr>
        <td>" .$rs['empId']."</td>
        <td>".$rs['birthdate']. "</td>
        <td>".$rs['firstname']. "</td>
        <td>".$rs['lastname']. "</td>
        <td>".$rs['hire_date']. "</td>
        </tr>";
    }
    $response = $response .
            "</table>
             </body>
             </html>";
    
 
                      return $response;
                   return json_encode($results);
           }

 //retrieve more than one name
 function getEmployeeNames($names, $birthdate){
    $dsn = "mysql:host=localhost;dbname=employees";
    $username = "root";
    $password = "";

    try {
        $db = new PDO($dsn, $username,$password);
    
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES,FALSE);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        error_reporting(E_ALL);
    
      } catch(PDOException $ex){
    
        header("Location:error.php?msg="  . $ex->getMessage());
      }

      $query = "SELECT * from employee where firstname = :names AND birthdate = :birthdate";
      $statement = $db->prepare($query);
      $statement->bindValue(":names", $names);
      $statement->bindValue(":birthdate", $birthdate);
      $statement->execute();
      $results = $statement->fetchAll();
      $statement->closeCursor();
        $response = "<HTML>
    <HEAD>
        <TITLE>Employee Information table</TITLE>
    </HEAD>
    <BODY>
    <br>
    <table border>
    <tr>
    <th>Employee Id:</th>
    <th>Birthdate</th> 
    <th>Firstname</th>
    <th>Lastname</th>
    <th>Hire-date</th>
    </tr>";
    foreach($results as $rs){
        $response = $response .
        "<tr>
        <td>" .$rs['empId']."</td>
        <td>".$rs['birthdate']. "</td>
        <td>".$rs['firstname']. "</td>
        <td>".$rs['lastname']. "</td>
        <td>".$rs['hire_date']. "</td>
        </tr>";
    }
    $response = $response .
            "</table>
             </body>
             </html>";
    
 
                      return $response;
 
      return json_encode($results);

 }

 ini_set("soap.wsdl_cache_enabled", "0");
 $server = new SoapServer("../ServiceProvider/index.wsdl");
 $server->addFunction("getEmployeeDetails");
$server->addFunction("getEmployeeNo");
$server->addFunction("getEmployeeNames");
$server->handle();